import "./chunks/modulepreload-polyfill.js";
import { p as processPages } from "./chunks/process.js";
import "./chunks/clean.js";
chrome.runtime.onMessage.addListener((m, _s, send) => {
  if (m?.target !== "offscreen" || m.type !== "process") return false;
  processPages(m.pages, m.settings).then(send);
  return true;
});
