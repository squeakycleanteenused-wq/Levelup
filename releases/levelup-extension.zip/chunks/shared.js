import { c as cleanSecret } from "./clean.js";
var define_LEVELUP_DEFAULTS_default = { supabaseUrl: "https://mgugwhjigjsylgjtksqy.supabase.co", supabaseKey: "sb_publishable_rsTQxqsIY64aZ7UP9sll9A_AU1VgUcH", password: "" };
const defaults = {
  host: "variku.ope.ee",
  supabaseUrl: cleanSecret(define_LEVELUP_DEFAULTS_default.supabaseUrl),
  supabaseKey: cleanSecret(define_LEVELUP_DEFAULTS_default.supabaseKey),
  password: define_LEVELUP_DEFAULTS_default.password,
  teacher: "Olena",
  className: "5b",
  studentId: "",
  groupId: "",
  everyMin: 30
};
const getSettings = async () => {
  const saved = (await chrome.storage.local.get("settings")).settings ?? {};
  const merged = { ...defaults };
  Object.entries(saved).forEach(([k, v]) => {
    if (v !== "" && v !== void 0) merged[k] = v;
  });
  ["supabaseUrl", "supabaseKey", "password"].forEach((k) => {
    if (defaults[k]) merged[k] = defaults[k];
  });
  return merged;
};
const saveSettings = (s) => chrome.storage.local.set({ settings: s });
const getStatus = async () => (await chrome.storage.local.get("status")).status ?? null;
const setStatus = (s) => chrome.storage.local.set({ status: s });
export {
  getStatus as a,
  setStatus as b,
  defaults as d,
  getSettings as g,
  saveSettings as s
};
