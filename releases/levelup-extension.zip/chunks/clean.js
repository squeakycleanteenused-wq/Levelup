function cleanSecret(s) {
  return (s ?? "").replace(/[‐-―−﹘﹣－]/g, "-").replace(/[‘’“”"']/g, "").replace(/[^\x21-\x7E]/g, "").trim();
}
export {
  cleanSecret as c
};
